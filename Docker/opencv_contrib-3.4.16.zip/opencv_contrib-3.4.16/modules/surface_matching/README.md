Point Pair Features for 3D Surface Matching
===========================================

Implements 3d object detection and localization using multimodal point pair features.
http://docs.opencv.org/3.0-beta/modules/surface_matching/doc/surface_matching.html
