// Compatibility
#include "shadow_sift.hpp"
