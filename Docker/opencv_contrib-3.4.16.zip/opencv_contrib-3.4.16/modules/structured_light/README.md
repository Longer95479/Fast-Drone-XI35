Structured Light Use
====================

How to generate and project gray code patterns and use them to find dense depth in a scene.
