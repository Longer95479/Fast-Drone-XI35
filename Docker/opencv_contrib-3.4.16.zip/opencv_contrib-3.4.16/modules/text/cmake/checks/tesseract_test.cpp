#if !defined(USE_STD_NAMESPACE)
#define USE_STD_NAMESPACE
#endif
#include <tesseract/baseapi.h>
#include <tesseract/resultiterator.h>

static void test()
{
    tesseract::TessBaseAPI tess;
}

int main() { test(); return 0; }
