#ifdef HAVE_OPENCV_XIMGPROC
typedef cv::ximgproc::EdgeDrawing::Params EdgeDrawing_Params;
#endif
